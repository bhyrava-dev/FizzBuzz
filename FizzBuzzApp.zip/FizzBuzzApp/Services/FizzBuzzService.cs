﻿using FizzBuzzApp.Models;
using System.Collections.Generic;
namespace FizzBuzzApp.Services
{
    public class FizzBuzzService
    {
        public List<FizzBuzzResult> ProcessInput(string input)
        {
            var results = new List<FizzBuzzResult>();
            var values = input.Split(',');

            foreach (var value in values)
            {
                if (int.TryParse(value.Trim(), out int number))
                {
                    if (number % 3 == 0 && number % 5 == 0)
                    {
                        results.Add(new FizzBuzzResult { Input = value, Output = "FizzBuzz" });
                    }
                    else if (number % 3 == 0)
                    {
                        results.Add(new FizzBuzzResult { Input = value, Output = "Fizz" });
                    }
                    else if (number % 5 == 0)
                    {
                        results.Add(new FizzBuzzResult { Input = value, Output = "Buzz" });
                    }
                    else
                    {
                        results.Add(new FizzBuzzResult { Input = value, Output = $"Divided {value} by 3\nDivided {value} by 5" });
                    }
                }
                else
                {
                    results.Add(new FizzBuzzResult { Input = value, Output = "Invalid item" });
                }
            }

            return results;
        }
    }
}
