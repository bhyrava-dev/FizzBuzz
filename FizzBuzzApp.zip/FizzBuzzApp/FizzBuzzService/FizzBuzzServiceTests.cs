﻿using FizzBuzzApp.Services;
using System.Linq;
using xUnit;
using xUnit.runner.visualstudio;

namespace FizzBuzzApp.FizzBuzzService
{
    public class FizzBuzzServiceTests
    {
        [Fact]
        public void ProcessInput_WithValidInput_ReturnsCorrectResults()
        {
            // Arrange
            var service = new FizzBuzzService();
            var input = "1,3,5,15,A,23";

            // Act
            var results = service.ProcessInput(input);

            // Assert
            Assert.Equal(6, results.Count);
            Assert.Contains(results, r => r.Output.Contains("Divided 1 by 3"));
            Assert.Contains(results, r => r.Output.Contains("Fizz"));
            Assert.Contains(results, r => r.Output.Contains("Buzz"));
            Assert.Contains(results, r => r.Output.Contains("FizzBuzz"));
            Assert.Contains(results, r => r.Output.Contains("Invalid item"));
            Assert.Contains(results, r => r.Output.Contains("Divided 23 by 3"));
        }
    }
}
