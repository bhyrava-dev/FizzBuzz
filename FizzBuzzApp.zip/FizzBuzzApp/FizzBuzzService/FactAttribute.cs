﻿
namespace FizzBuzzApp.FizzBuzzService
{
    internal class FactAttribute : Attribute
    {
    }
}