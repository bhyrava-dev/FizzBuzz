﻿namespace FizzBuzzApp.Models
{
    public class FizzBuzzResult
    {
        public string Input { get; set; }
        public string Output { get; set; }
    }
}
