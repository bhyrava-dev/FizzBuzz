﻿using Microsoft.AspNetCore.Mvc;
using FizzBuzzApp.Models;
using FizzBuzzApp.Services;

namespace FizzBuzzApp.Controllers
{
    public class FizzBuzzController : Controller
    {
        private readonly FizzBuzzService _fizzBuzzService;

        public FizzBuzzController()
        {
            _fizzBuzzService = new FizzBuzzService();
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(string input)
        {
            var results = _fizzBuzzService.ProcessInput(input);
            return View(results);
        }
    }
}
